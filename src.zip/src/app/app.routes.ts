import { Routes } from '@angular/router';
import { NotFoundComponent } from './components/not-found/not-found';

export const routes: Routes = [
    
    {path: '**', component: NotFoundComponent},
];
